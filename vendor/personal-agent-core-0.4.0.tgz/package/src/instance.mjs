import {mkdir, readFile, writeFile, rename, lstat, unlink} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import lockfile from 'proper-lockfile';
import {PackageError, resolvePackages} from './index.mjs';
import {prepareSkills} from './skills.mjs';
const fail=code=>{throw new PackageError(code);};

// The host supplies trusted, already-installed packages. Never discover or install code.
export class InstancePackages {
 constructor(directory, installed, defaults=[]) {
  this.directory=path.resolve(directory); this.file=path.join(this.directory,'instance.json');
  this.installed=installed; this.defaults=defaults;
  const keys=new Set();
  for(const pkg of installed){const key=pkg.id+'@'+pkg.version;if(keys.has(key))fail('DUPLICATE_PACKAGE');keys.add(key);}
 }
 select(bindings){
  if(!Array.isArray(bindings)||bindings.some(b=>!b||typeof b.id!=='string'||typeof b.version!=='string'))fail('INVALID_INSTANCE');
  return bindings.map(b=>{const pkg=this.installed.find(p=>p.id===b.id&&p.version===b.version);if(!pkg)fail('PACKAGE_NOT_INSTALLED');return pkg;});
 }
 async validate(bindings){
  const packages=this.select(bindings), resolved=resolvePackages(packages);
  const resources=await prepareSkills(packages,resolved.tools);
  resources.cleanup(); return resolved.bindings;
 }
 async read(){
  let data;
  try {if((await lstat(this.file)).isSymbolicLink())fail('INVALID_INSTANCE');data=JSON.parse(await readFile(this.file,'utf8'));}
  catch(error){if(error.code==='ENOENT')data={schemaVersion:1,packages:this.defaults};else throw error;}
  if(data.schemaVersion!==1)fail('INVALID_INSTANCE');
  return {schemaVersion:1,packages:await this.validate(data.packages)};
 }
 async update(bindings){
  const packages=await this.validate(bindings);
  await mkdir(this.directory,{recursive:true,mode:0o700});
  if((await lstat(this.directory)).isSymbolicLink())fail('INVALID_INSTANCE');
  const release=await lockfile.lock(this.directory,{realpath:false,retries:0});
  const temporary=this.file+'.'+randomUUID()+'.pending';
  try {await writeFile(temporary,JSON.stringify({schemaVersion:1,packages},null,2)+'\n',{mode:0o600,flag:'wx'});await rename(temporary,this.file);return await this.read();}
  finally {await unlink(temporary).catch(error=>{if(error.code!=='ENOENT')throw error;});await release();}
 }
 async catalog(){
  const config=await this.read(), packages=[];
  for(const pkg of this.installed){
   let error;
   try {await this.validate([{id:pkg.id,version:pkg.version},...config.packages.filter(b=>b.id!==pkg.id)]);}catch(e){error=e.code||'INVALID_PACKAGE';}
   packages.push({id:pkg.id,version:pkg.version,enabled:config.packages.some(b=>b.id===pkg.id&&b.version===pkg.version),compatible:!error,...(error?{error}:{}),tools:pkg.tools.map(t=>t.name),skills:(pkg.skills||[]).map(s=>({path:s.path,requiresTools:s.requiresTools}))});
  }
  return {...config,installed:packages,effect:'new_sessions'};
 }
 async forSession(manager){
  const bound=[...manager.getBranch()].reverse().find(e=>e.type==='custom'&&e.customType==='personal-agent-packages');
  return this.select(bound?bound.data:(await this.read()).packages);
 }
}
