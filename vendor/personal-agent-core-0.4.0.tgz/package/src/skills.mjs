import {loadSkills, formatSkillsForPrompt} from '@earendil-works/pi-coding-agent';
import {mkdtemp, mkdir, readFile, writeFile, realpath, lstat, rm} from 'node:fs/promises';
import {rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {PackageError} from './index.mjs';
const fail=code=>{throw new PackageError(code);};
const validPath=value=>typeof value==='string' && value.length>0 && !value.includes('\\') && !value.includes('\0') && !path.isAbsolute(value) && value.split('/').every(p=>p && p!=='.' && p!=='..') && value.endsWith('.md');
const digest=content=>createHash('sha256').update(content).digest('hex');
const inside=(root,file)=>file.startsWith(root+path.sep);

// Only exact declared markdown files are read. Pi never receives a directory to scan.
async function source(pkg,entry){
 if (!validPath(entry.path)) fail('INVALID_SKILL_PATH');
 if (entry.content!==undefined) {
  if(typeof entry.content!=='string') fail('INVALID_SKILL');
  return entry.content; // Trusted host embeds the same packaged bytes for standalone bundles.
 }
 if(typeof pkg.resourceRoot!=='string'||!path.isAbsolute(pkg.resourceRoot)) fail('INVALID_SKILL_ROOT');
 let root,file;
 try {
  root=await realpath(pkg.resourceRoot);
  file=await realpath(path.join(root,entry.path));
  if(!inside(root,file)) fail('SKILL_PATH_ESCAPE');
  if(!(await lstat(file)).isFile()) fail('INVALID_SKILL_PATH');
  return await readFile(file,'utf8');
 }catch(error){if(error instanceof PackageError)throw error;if(error.code==='ENOENT')fail('SKILL_NOT_FOUND');fail('SKILL_READ_FAILED');}
}

export async function prepareSkills(packages,tools,pinned){
 const enabled=new Map(packages.map(p=>[p.id,p])), toolNames=new Set(tools.map(t=>t.name));
 let snapshot=pinned;
 if(snapshot===undefined){
  snapshot=[];
  for(const pkg of packages) for(const entry of pkg.skills||[]){
   if(!entry||!validPath(entry.path)||!Array.isArray(entry.requiresTools)||entry.requiresTools.some(n=>typeof n!=='string')) fail('INVALID_SKILL_PATH');
   if(entry.requiresTools.some(n=>!toolNames.has(n)||n==='read_skill')) fail('MISSING_SKILL_TOOL');
   const content=await source(pkg,entry);
   snapshot.push({packageId:pkg.id,version:pkg.version,path:entry.path,requiresTools:[...entry.requiresTools],content,sha256:digest(content)});
  }
 }
 if(!Array.isArray(snapshot)) fail('INVALID_SKILL_SNAPSHOT');
 if(!snapshot.length)return {snapshot,skills:[],tools,prompt:'',cleanup:()=>{}};
 if(toolNames.has('read_skill')) fail('DUPLICATE_TOOL');
 const directory=await mkdtemp(path.join(tmpdir(),'personal-agent-skills-'));
 try{
  const skills=[], names=new Set(), records=new Map();
  for(const record of snapshot){
   const pkg=enabled.get(record.packageId);
   if(!pkg||pkg.version!==record.version||!validPath(record.path)||typeof record.content!=='string'||digest(record.content)!==record.sha256)fail('INVALID_SKILL_SNAPSHOT');
   if(!Array.isArray(record.requiresTools)||record.requiresTools.some(n=>!toolNames.has(n)||n==='read_skill'))fail('MISSING_SKILL_TOOL');
   const key=record.packageId+'/'+record.path;
   if(records.has(key))fail('DUPLICATE_SKILL');
   const file=path.join(directory,record.packageId,record.path);
   await mkdir(path.dirname(file),{recursive:true,mode:0o700});await writeFile(file,record.content,{mode:0o600,flag:'wx'});
   const result=loadSkills({cwd:directory,agentDir:directory,skillPaths:[file],includeDefaults:false});
   if(result.diagnostics.length||result.skills.length!==1)fail('INVALID_SKILL');
   const skill=result.skills[0];
   if(names.has(skill.name))fail('DUPLICATE_SKILL');
   names.add(skill.name);records.set(key,record);skills.push(skill);
  }
  const reader={name:'read_skill',label:'Read skill',description:'Read the full pinned markdown of one explicitly enabled package skill. Only exact catalog packageId/path pairs are accepted; no general filesystem access.',parameters:{type:'object',properties:{packageId:{type:'string'},path:{type:'string'}},required:['packageId','path'],additionalProperties:false},execute:async(_id,args)=>{
   if(!args||!validPath(args.path))fail('INVALID_SKILL_PATH');
   if(!enabled.has(args.packageId))fail('SKILL_PACKAGE_NOT_ENABLED');
   const record=records.get(args.packageId+'/'+args.path);
   if(!record)fail('SKILL_NOT_DECLARED');
   return {content:[{type:'text',text:record.content}]};
  }};
  // Pi's stock prompt hides skills without read/bash. Reuse its formatter with a restricted reader hint.
  const catalog=skills.map((skill,i)=>({...skill,filePath:JSON.stringify({packageId:snapshot[i].packageId,path:snapshot[i].path})}));
  return {snapshot,skills,tools:[...tools,reader],prompt:'Use read_skill with the exact packageId and path in each location to load skill instructions. Skills never grant tools or authorization.\n'+formatSkillsForPrompt(catalog,'indirect'),cleanup:()=>rmSync(directory,{recursive:true,force:true})};
 }catch(error){await rm(directory,{recursive:true,force:true});throw error;}
}
