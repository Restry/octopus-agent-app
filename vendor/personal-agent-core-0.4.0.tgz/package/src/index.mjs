import {createAgentSession, SessionManager, SettingsManager, ModelRuntime, createExtensionRuntime} from '@earendil-works/pi-coding-agent';
import {InMemoryCredentialStore} from '@earendil-works/pi-ai';
import {mkdir, lstat, chmod, writeFile, readdir, unlink} from 'node:fs/promises';
import path from 'node:path';
import lockfile from 'proper-lockfile';
import {prepareSkills} from './skills.mjs';
import {memoryPrompt} from './memory.mjs';
export {InstancePackages} from './instance.mjs';
export {JsonMemoryProvider, MemoryError, validateMemoryContent, memoryPrompt} from './memory.mjs';

export class PackageError extends Error {
  constructor(code) { super(code); this.name = 'PackageError'; this.code = code; }
}
const fail = code => { throw new PackageError(code); };
const version = value => typeof value === 'string' && /^\d+\.\d+\.\d+$/.test(value);
const packageId = value => typeof value === 'string' && /^[a-z][a-z0-9.-]*$/.test(value);

export function resolvePackages(packages = []) {
  if (!Array.isArray(packages)) fail('INVALID_PACKAGE');
  const byId = new Map(), names = new Set(), tools = [];
  for (const pkg of packages) {
    if (!pkg || !packageId(pkg.id) || !version(pkg.version)) fail('INVALID_PACKAGE');
    if (pkg.apiVersion !== 1 || pkg.runtime !== 'node') fail('INCOMPATIBLE_PACKAGE');
    if (byId.has(pkg.id)) fail(byId.get(pkg.id).version === pkg.version ? 'DUPLICATE_PACKAGE' : 'PACKAGE_VERSION_CONFLICT');
    if (!Array.isArray(pkg.tools) || !Array.isArray(pkg.permissions) || pkg.permissions.some(p=>typeof p !== 'string') || !pkg.dependencies || typeof pkg.dependencies !== 'object' || Array.isArray(pkg.dependencies)) fail('INVALID_PACKAGE');
    for (const resource of ['extensions','display']) if (pkg[resource] !== undefined && (!Array.isArray(pkg[resource]) || pkg[resource].length)) fail('UNSUPPORTED_RESOURCE');
    if (pkg.skills !== undefined && !Array.isArray(pkg.skills)) fail('INVALID_PACKAGE');
    byId.set(pkg.id, pkg);
    for (const tool of pkg.tools) {
      if (!tool || typeof tool.name !== 'string' || !/^[A-Za-z_][A-Za-z0-9_-]*$/.test(tool.name) || typeof tool.execute !== 'function' || !tool.parameters) fail('INVALID_PACKAGE');
      if (names.has(tool.name)) fail('DUPLICATE_TOOL');
      names.add(tool.name);
      tools.push(tool);
    }
  }
  for (const pkg of packages) for (const [id, required] of Object.entries(pkg.dependencies)) {
    if (!packageId(id) || !version(required)) fail('INVALID_PACKAGE');
    if (!byId.has(id)) fail('MISSING_DEPENDENCY');
    if (byId.get(id).version !== required) fail('DEPENDENCY_VERSION_CONFLICT');
  }
  return {tools, bindings:packages.map(({id,version})=>({id,version})).sort((a,b)=>a.id.localeCompare(b.id))};
}

// Pi's ResourceLoader interface, with no ambient discovery. DefaultResourceLoader.reload
// scans ancestor/home resource directories even with every no* option enabled in Pi 1.4.0.
function explicitResources(systemPrompt, skills = []) {
  const extensions = {extensions:[],errors:[],runtime:createExtensionRuntime()};
  return {
    getExtensions:()=>extensions,
    getSkills:()=>({skills,diagnostics:[]}),
    getPrompts:()=>({prompts:[],diagnostics:[]}),
    getThemes:()=>({themes:[],diagnostics:[]}),
    getAgentsFiles:()=>({agentsFiles:[]}),
    getSystemPrompt:()=>systemPrompt,
    getSystemPromptSource:()=>undefined,
    getAppendSystemPrompt:()=>[],
    getAppendSystemPromptSources:()=>[],
    extendResources:()=>fail('UNSUPPORTED_RESOURCE'),
    reload:async()=>{},
  };
}

export class PersonalAgentRuntime {
  constructor(directory, {title = text => text} = {}) {
    if (typeof directory !== 'string' || !directory) throw new TypeError('Explicit session directory required');
    this.directory = path.resolve(directory);
    this.title = title;
  }
  async init() {
    await mkdir(this.directory, {recursive:true, mode:0o700});
    if ((await lstat(this.directory)).isSymbolicLink()) throw new Error('拒绝符号链接会话目录');
    await chmod(this.directory, 0o700);
  }
  file(id) {
    if (typeof id !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id)) throw new Error('会话无效');
    return path.join(this.directory, `${id}.jsonl`);
  }
  async manager(id) {
    await this.init();
    const file = this.file(id), info = await lstat(file);
    if (!info.isFile() || info.isSymbolicLink()) throw new Error('会话文件无效');
    await chmod(file, 0o600);
    return SessionManager.open(file, this.directory, this.directory);
  }
  async create(packages) {
    await this.init();
    let manager = SessionManager.create(this.directory, this.directory);
    const id = manager.getSessionId();
    await writeFile(this.file(id), JSON.stringify(manager.getHeader())+'\n', {mode:0o600, flag:'wx'});
    manager = await this.manager(id);
    if (packages !== undefined) {
      const {tools,bindings}=resolvePackages(packages);
      const resources=await prepareSkills(packages,tools);
      try {
        manager.appendCustomEntry('personal-agent-packages',bindings);
        manager.appendCustomEntry('personal-agent-skills',resources.snapshot);
      } finally {resources.cleanup();}
    }
    return {sessionId:id};
  }
  async list() {
    await this.init();
    const sessions = [];
    for (const name of await readdir(this.directory)) {
      if (!/^[0-9a-f-]{36}\.jsonl$/.test(name)) continue;
      const id = name.slice(0,-6), manager = await this.manager(id), entries = manager.getBranch();
      const user = entries.find(e=>e.type==='message' && e.message.role==='user');
      const content = user?.message.content;
      const text = typeof content === 'string' ? content : content?.filter(c=>c.type==='text').map(c=>c.text).join('\n');
      const title = text ? this.title(text) : '新对话';
      sessions.push({id,title:title.slice(0,40),updatedAt:Date.parse(entries.at(-1)?.timestamp || manager.getHeader().timestamp)});
    }
    return {sessions:sessions.sort((a,b)=>b.updatedAt-a.updatedAt)};
  }
  async lease(id, fn) {
    await this.manager(id);
    let release;
    try { release = await lockfile.lock(this.file(id), {realpath:false,stale:10000,update:2000,retries:0}); }
    catch { throw new Error('该会话正在执行，请稍后重试'); }
    try { return await fn(await this.manager(id)); } finally { await release(); }
  }
  async remove(id) { return this.lease(id, async()=> { await unlink(this.file(id)); return {deleted:true}; }); }
  async open(manager, {model,packages = [],systemPrompt,stream,redact,memory}) {
    if (typeof stream !== 'function' || typeof redact !== 'function') throw new TypeError('Host stream and redact are required');
    const {tools,bindings} = resolvePackages(packages);
    if (memory) {
      const names = new Set(tools.map(t=>t.name));
      for (const tool of memory.tools || []) { if (names.has(tool.name)) fail('DUPLICATE_TOOL'); names.add(tool.name); tools.push(tool); }
      systemPrompt = [systemPrompt, await memoryPrompt(memory)].filter(Boolean).join('\n\n');
    }
    const bound = [...manager.getBranch()].reverse().find(e=>e.type==='custom' && e.customType==='personal-agent-packages');
    if (bound && JSON.stringify(bound.data) !== JSON.stringify(bindings)) fail('SESSION_PACKAGE_CONFLICT');
    const pinned = [...manager.getBranch()].reverse().find(e=>e.type==='custom' && e.customType==='personal-agent-skills');
    const resources = await prepareSkills(packages, tools, pinned ? pinned.data : bound ? [] : undefined);
    let modelRuntime;
    let session;
    try {
      const settingsManager=SettingsManager.inMemory({compaction:{enabled:true},retry:{enabled:false},cacheWarming:'off'});
      modelRuntime=await ModelRuntime.create({credentials:new InMemoryCredentialStore(),modelsPath:null,refreshOnCreate:false});
      modelRuntime.hasConfiguredAuth=()=>true;
      modelRuntime.streamSimple=stream;
      ({session}=await createAgentSession({cwd:this.directory,agentDir:this.directory,model,modelRuntime,sessionManager:manager,settingsManager,resourceLoader:explicitResources([systemPrompt,resources.prompt].filter(Boolean).join('\n\n'),resources.skills),noTools:'builtin',tools:resources.tools.map(t=>t.name),customTools:resources.tools,thinkingLevel:model.reasoning?'low':'off'}));
    } catch (error) {await resources.cleanup();throw error;}
    if (!bound) manager.appendCustomEntry('personal-agent-packages',bindings);
    if (!pinned) manager.appendCustomEntry('personal-agent-skills',resources.snapshot);
    const append=manager.appendMessage;
    const filtered=message=>append.call(manager,JSON.parse(redact(JSON.stringify(message))));
    manager.appendMessage=filtered;
    const dispose=session.dispose.bind(session);
    session.dispose=()=>{try{dispose();}finally{if(manager.appendMessage===filtered)manager.appendMessage=append;void resources.cleanup();}};
    return session;
  }
}
