# Personal Agent Core

独立 Node ESM 项目，Pi SDK 1.4.0 会话、私有会话存储、租约、显式能力包加载与可替换长期记忆 provider。实例、项目与业务数据归属见 [contracts.md](contracts.md)。不包含门神业务或技能演进。

```sh
npm ci --ignore-scripts
npm test
npm run probe:pi
npm pack --ignore-scripts
```

使用 `import {PersonalAgentRuntime} from '@personal-agent/core'`，传显式实例会话目录；`open` 接收主机 model/stream/redact 与 packages，返回 Pi 原生 AgentSession。以 lease 包围 open/prompt/waitForIdle/dispose。模型传输与业务过滤均由主机维护。已实现显式包技能目录与 `read_skill({packageId,path})`，复用 Pi 原生解析和目录格式，不开放通用文件或 bash；会话保存全文快照，包更新不替换旧会话资源。技能声明、依赖和路径错误见契约。extensions/display 尚未开放。

门神消费版本为 0.4.0，`npm pack` 生成 `personal-agent-core-0.4.0.tgz`。将该文件复制到门神 `vendor/`，门神使用 `file:vendor/personal-agent-core-0.4.0.tgz`；在门神执行 `npm install --ignore-scripts` 与 `pnpm install --lockfile-only --ignore-scripts` 更新两种锁，再执行相关回归与 bundle。运行和 CI 无需 sibling repo、npm link 或绝对路径。不得原地更新同名 tarball 后仍使用旧锁 integrity；发布给消费者的新行为应升级版本、生成新产物并更新依赖。

门神 esbuild 把本包内联到原 sidecar 单文件，运行无 node_modules 或邻仓要求；Python/WSL 业务资源仍由门神打包。首次打开旧会话绑定当前包版本，已绑定会话拒绝改变启用集和版本，切换包需新会话。

`InstancePackages(directory, installed, defaults)` 管理显式实例目录的 `instance.json`；`catalog/read/update/forSession` 提供已安装包、兼容校验、原子持久化和会话绑定选择。宿主通过 `create(packages)` 在新会话创建时保存版本与技能快照，启停或回退只影响之后创建的会话。不会扫描或安装代码。

`JsonMemoryProvider(absoluteDirectory, projectId)` 提供 recall/remember/update/forget；个人偏好明确共享，项目事实只能访问构造时项目。私有 JSON 文件原子写入、跨进程锁、重启读回、版本冲突拒绝和物理删除；不依赖外部账号或向量库。`open(...,{memory:{provider,query,tools}})` 在普通对话前召回最多 3 条个人偏好与 5 条词法相关项目事实，附来源和版本。没有自动历史抽取；秘密格式与临时进度拒绝，宿主仍须过滤已知 secret。词法检索及预算可能漏召回。参见契约中的完整限制。
