# Personal Agent Core 契约 1

本项目独立于门神 repo。Node >=22.19；Pi @earendil-works/pi-coding-agent / pi-ai 固定 1.4.0。公开入口 @personal-agent/core；不发布 npm，不扫描全机项目，不读取用户 auth.json/models.json，不包含 vault 业务。

## 能力包

主机显式 import 已安装模块，并向 runtime.open 传 packages。每个模块返回普通对象：

```js
{ id: 'menshen', version: '0.4.2', apiVersion: 1, runtime: 'node',
  dependencies: {}, permissions: ['vault:metadata'],
  tools: [/* Pi ToolDefinition，原生 parameters / execute */] }
```

id 必须是小写字母开头的字母、数字、点、横线；version 是精确 x.y.z；dependencies 是包 id 到精确版本的对象，仅允许已显式启用包满足。数组顺序即工具顺序；相同 id 不可重复，版本不同时为 PACKAGE_VERSION_CONFLICT，同版本为 DUPLICATE_PACKAGE。依赖缺失为 MISSING_DEPENDENCY，版本不符为 DEPENDENCY_VERSION_CONFLICT，重复工具名为 DUPLICATE_TOOL，API 不兼容为 INCOMPATIBLE_PACKAGE，其他清单问题为 INVALID_PACKAGE。工具遵循 Pi 原生执行/错误事件；业务工具失败由主机转换为安全错误，不泄漏插件诊断。

skills 可选，格式为 [{path:'skills/example/SKILL.md',requiresTools:['query']}], resourceRoot 是包根绝对目录。只接受精确声明的相对 .md 文件；拒绝绝对路径、点路径、反斜线、空组件、越目录符号链接，分别报 INVALID_SKILL_PATH / SKILL_PATH_ESCAPE，缺文件报 SKILL_NOT_FOUND。主机可在打包时用 entry.content 内联相同发行字节，运行时不再读源目录；包代码及内联内容属于可信主机输入，不能由模型指定。每个技能 requiresTools 必须来自显式已启用工具集合，缺失报 MISSING_SKILL_TOOL；技能不能启用工具或授予授权。Pi 1.4.0 loadSkills({skillPaths:[精确快照文件],includeDefaults:false}) 负责 frontmatter/名称/描述解析；诊断报 INVALID_SKILL，同名及重复入口报 DUPLICATE_SKILL。不调用扫描全机目录的 DefaultResourceLoader。extensions/display 非空仍报 UNSUPPORTED_RESOURCE。

只在存在技能时添加 read_skill({packageId,path})，仅返回该包声明条目的固定全文；不能访问同包其他文件、另一个包目录或任意 secret 路径。未启用包报 SKILL_PACKAGE_NOT_ENABLED，非声明条目报 SKILL_NOT_DECLARED；同名主机工具冲突报 DUPLICATE_TOOL。目录用 Pi formatSkillsForPrompt(indirect) 生成，主机提示明确使用 read_skill；不开放 builtin read/bash。Pi ResourceLoader 提供同一批原生 Skill，原生 /skill:name 也只读私有临时快照，dispose 同步删除快照。临时目录 0700、文件 0600。

包代码是可信本机代码，不是沙箱；permissions 是审计声明，不是权限隔离。主机包工具执行器必须实施 scope、授权、防覆盖和结果过滤，插件不可取消过滤。包不得携带模型密钥、实例配置、凭据或业务存储。

新会话首次 open 固定 [{id,version}]（排序仅用于比较，不改变工具顺序），写入 Pi custom entry personal-agent-packages。重开版本或启用集变化报 SESSION_PACKAGE_CONFLICT，需新建会话；旧门神历史首次 open 绑定当前启用版本。personal-agent-skills 同时保存技能全文、requiresTools、packageId/version/path 和 SHA-256，重开从会话快照解析并校验依赖及哈希，不从更新后的包读取；新会话才接收新资源。首次启用技能前已打开的旧会话保留空技能快照。正在运行会话不接受资源 reload。packages:[] 无业务工具、技能 reader 或 Pi builtin 工具。

InstancePackages(directory, installed, defaults) 仅接收宿主显式提供的已安装包，不扫描、下载或执行任意路径。instance.json 使用 schemaVersion:1、packages:[{id,version}]，原子写入、0600 和跨进程独占锁；read/update 校验兼容性、依赖、工具和技能冲突。catalog 返回真实版本、enabled、compatible、错误码与工具/技能入口。未知版本报 PACKAGE_NOT_INSTALLED。forSession 优先使用已有绑定，实例修改只影响新会话；旧版本必须仍在 installed 中，缺失时明确失败，不偷偷替换。

create(packages) 可在创建时固定包绑定和技能全文快照；无参 create 保留首次 open 绑定行为。宿主应在新会话创建时传实例选中包，保证尚未发言的已有会话也不随设置改变。

## 会话、事件与主机边界

PersonalAgentRuntime(directory, {title?}) 要求主机显式传私有会话目录；create/list/manager/lease/remove 管理 Pi JSONL 与独占租约。open(manager,{model,packages,systemPrompt,stream,redact}) 返回原生 AgentSession。stream 与 redact 必须由主机提供，ModelRuntime 使用 InMemoryCredentialStore、modelsPath:null、refreshOnCreate:false；不回退用户模型配置。redact 处理每次 appendMessage（主机同时过滤输出事件、工具结果与 custom entry）。异常不包含模型或业务数据。

事件直接使用 Pi subscribe：message_start/update/end、tool_execution_start/end、agent_settled；取消使用 abort，结束使用 waitForIdle/dispose。门神主机继续输出原有 text_delta/tool/done JSONL，历史每页 50 条，工具跟随 afterMessageId；底座不定义第二套 UI 协议。SessionManager 的 custom entry 属于主机，可保留业务迁移方案，不能成为 core 的 vault 导入。

## 数据归属

| 数据 | 所有者及位置 | 隔离要求 |
| --- | --- | --- |
| 实例身份/启用包/模型传输 | 嵌入主机显式配置；core 无全局单例或默认目录；InstancePackages 管理指定目录 instance.json | 不同实例传不同 directory；模型认证仍由主机管理 |
| 项目身份/范围 | 业务主机的 project/context，门神 scope 原样保留 | 项目范围由工具主机执行，不能仅靠 prompt |
| 会话 | 实例私有 directory/<uuid>.jsonl、同目录租约 | 目录 0700、文件 0600；门神继续 MENSHEN_AGENT_DIR 或 ~/.menshen-agent/sessions，绝不迁进 vault |
| 个人记忆/项目长期记忆 | 宿主固定实例目录下独立 memory/memory.json，不在 vault | personal 显式共享个人偏好；project 由构造函数固定项目身份，不接受模型项目或路径 |
| 业务凭据/元数据/事务 | 门神 vault 包及其既有本机存储 | core 不 import vault、不迁移业务数据；真值不进入模型/会话/日志 |
| 模型认证 | 主机内存及原有凭据引用 | core 不读 ~/.vault、不持久化 key/config |

相同物理 directory 表示相同实例的存储域；调用方负责选择不同域。独立项目不意味着共享所有实例数据。

## 长期记忆 provider（0.4.0）

可替换 provider 必须实现异步 recall({scope,query?,limit?})、remember({scope,content,source})、update({scope,id,content,expectedRevision,source})、forget({scope,id,expectedRevision})。scope 仅 personal/project；项目身份及绝对实例目录只由宿主构造时提供。记录含 id、scope、projectId、kind（preference/fact）、content、revision 和 sources 来源链；纠正替换旧内容并递增版本、追加来源，版本冲突拒绝写入。删除物理移除记录与来源，不能再召回；不删除已有会话历史或备份。

JsonMemoryProvider 使用既有 proper-lockfile 跨进程互斥、私有 0700 目录、0600 文件、O_NOFOLLOW 拒绝文件符号链接、随机 wx 临时文件、fsync + 原子 rename；每次操作重新读盘，无进程缓存。最多 2000 条、文件最大 8 MiB，来源最多受整体文件上限约束。source 由宿主指定 conversation + sessionId 或 manager，不接受模型伪造来源。错误使用 MEMORY_*，损坏或不可用明确失败，不静默回退空记忆。

验证器拒绝显式秘密格式、长 token、控制字符和常见临时任务进度；此规则不是任意秘密的语义检测器，宿主必须同时拒绝已知 secret 值。默认不自动抽取或保存会话。个人共享只保存用户明确要求跨项目共享的个人偏好。门神工具写入还须当前轮显式记住/纠正/遗忘动词，否定请求拒绝；这是保守词法授权，可能要求用户改述。

open 的可选 memory={provider,query,tools?} 在打开每轮会话时重新检索并注入来源及版本数据。最多 3 条共享偏好及 5 条按英文词/中文双字匹配的项目事实；不使用向量或语义检索，可能漏召回，超过预算的偏好可能遗漏。内容是不可信数据，不得扩大指令权限。工具通过宿主包装继续执行原有脱敏、错误与事件策略；packages:[] 时门神不传 memory，停用仍没有工具。管理入口按 scope 查看（最多 200 条）、纠正与删除并读回；纠正删除下一轮生效，运行中已发出的模型请求不能收回。

## 打包与兼容性

core 自带 package-lock.json，独立 npm ci / npm test / npm run probe:pi。门神通过可携带 npm tarball file:vendor/personal-agent-core-0.4.0.tgz 消费，保留两仓独立 lock；更新时在 core npm pack，再拷贝指定 tarball 到门神 vendor 并重建门神锁。tarball 仅含源码与契约，不含 node_modules、实例数据或 secrets。bundle 使用 esbuild 内联 core 及门神技能正文，不依赖开发机绝对路径或运行时邻仓，Pi / Python / WSL 原有资源保持。原生重建输入包含包产物。

支持探针仅证明本机 SDK、隔离协议与 bundle；未执行 Windows GUI，不宣称 Windows 0.4.2 验收通过。P3 首片仅门神闭环，第二真实项目不是门槛；P4 不在本片。确定性模型传输只证明真实 Pi 工具循环，不能声称真实模型完成。
